package com.hesabdari.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/**
 * Persistent queue of bank SMS that arrived but have not yet been handed to the web app.
 * The receiver appends here; the web app reads with getAll() and removes with ack().
 * Nothing is removed until the web app confirms it has stored the messages.
 */
final class SmsStore {
    private static final String PREFS = "hesabdari_sms";
    private static final String KEY_QUEUE = "queue";
    private static final String KEY_SENDERS = "senders";
    private static final int MAX_QUEUE = 500;
    private static final Object LOCK = new Object();

    private SmsStore() {}

    static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Appends a message. Returns false if it is already queued or could not be saved. */
    static boolean add(Context c, String sender, String body, long ts) {
        synchronized (LOCK) {
            try {
                JSONArray arr = new JSONArray(prefs(c).getString(KEY_QUEUE, "[]"));
                String id = ts + "-" + Integer.toHexString((sender + "|" + body).hashCode());
                for (int i = 0; i < arr.length(); i++) {
                    if (id.equals(arr.getJSONObject(i).optString("id"))) return false;
                }
                JSONObject o = new JSONObject();
                o.put("id", id);
                o.put("sender", sender);
                o.put("body", body);
                o.put("ts", ts);
                arr.put(o);

                // Keep the queue bounded if the app is not opened for a very long time.
                if (arr.length() > MAX_QUEUE) {
                    JSONArray trimmed = new JSONArray();
                    for (int i = arr.length() - MAX_QUEUE; i < arr.length(); i++) {
                        trimmed.put(arr.get(i));
                    }
                    arr = trimmed;
                }
                return prefs(c).edit().putString(KEY_QUEUE, arr.toString()).commit();
            } catch (JSONException e) {
                return false;
            }
        }
    }

    static String getAll(Context c) {
        synchronized (LOCK) {
            return prefs(c).getString(KEY_QUEUE, "[]");
        }
    }

    /** Removes the given ids (a JSON array of strings) from the queue. */
    static void ack(Context c, String idsJson) {
        synchronized (LOCK) {
            try {
                JSONArray ids = new JSONArray(idsJson);
                Set<String> drop = new HashSet<>();
                for (int i = 0; i < ids.length(); i++) drop.add(ids.getString(i));

                JSONArray arr = new JSONArray(prefs(c).getString(KEY_QUEUE, "[]"));
                JSONArray keep = new JSONArray();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    if (!drop.contains(o.optString("id"))) keep.put(o);
                }
                prefs(c).edit().putString(KEY_QUEUE, keep.toString()).commit();
            } catch (JSONException e) {
                // leave the queue untouched; the web app de-duplicates anyway
            }
        }
    }

    static String getSenders(Context c) {
        return prefs(c).getString(KEY_SENDERS, "");
    }

    static void setSenders(Context c, String s) {
        prefs(c).edit().putString(KEY_SENDERS, s == null ? "" : s).apply();
    }
}
