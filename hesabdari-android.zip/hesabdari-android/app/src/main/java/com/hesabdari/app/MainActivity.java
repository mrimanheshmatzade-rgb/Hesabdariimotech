package com.hesabdari.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;

/**
 * Shell around the web app (assets/index.html). It adds what a browser cannot do:
 * receive bank SMS, show JS confirm() dialogs, pick a backup file and save one to Downloads.
 */
public class MainActivity extends Activity {
    private static final int REQ_PERMS = 41;
    private static final int REQ_FILE = 42;
    private static final String START_URL = "file:///android_asset/index.html";

    private static WeakReference<MainActivity> current = new WeakReference<>(null);

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage = where the ledger lives
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "AndroidSms");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // The bridge must only ever be reachable from the bundled page.
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pull();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("باشه", (d, w) -> result.confirm())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("بله", (d, w) -> result.confirm())
                        .setNegativeButton("خیر", (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.loadUrl(START_URL);

        // Ask for the SMS permission once, the first time the app is opened.
        SharedPreferences p = SmsStore.prefs(this);
        if (!hasSmsPermission() && !p.getBoolean("asked_perms", false)) {
            p.edit().putBoolean("asked_perms", true).apply();
            askPermissions();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        current = new WeakReference<>(this);
        pull();
    }

    @Override
    protected void onDestroy() {
        if (current.get() == this) current = new WeakReference<>(null);
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMS) callJs("window.onNativePerm && window.onNativePerm()");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (fileCallback != null) {
                Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                fileCallback.onReceiveValue(result);
                fileCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /** Called by SmsReceiver (any thread) when a new bank SMS was queued. */
    static void pokeWeb() {
        final MainActivity a = current.get();
        if (a != null) a.runOnUiThread(a::pull);
    }

    private void pull() {
        callJs("window.onNativeSms && window.onNativeSms()");
    }

    private void callJs(String js) {
        if (web != null) web.evaluateJavascript(js, null);
    }

    private boolean hasSmsPermission() {
        return checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    private void askPermissions() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{
                    Manifest.permission.RECEIVE_SMS,
                    Manifest.permission.POST_NOTIFICATIONS}, REQ_PERMS);
        } else {
            requestPermissions(new String[]{Manifest.permission.RECEIVE_SMS}, REQ_PERMS);
        }
    }

    /** Methods the web page can call as window.AndroidSms.xxx(). Runs on a background thread. */
    public class Bridge {
        @JavascriptInterface
        public String getPending() {
            return SmsStore.getAll(MainActivity.this);
        }

        @JavascriptInterface
        public void ack(String idsJson) {
            SmsStore.ack(MainActivity.this, idsJson);
        }

        @JavascriptInterface
        public boolean hasPermission() {
            return hasSmsPermission();
        }

        @JavascriptInterface
        public void requestPermission() {
            runOnUiThread(() -> askPermissions());
        }

        @JavascriptInterface
        public String getSenders() {
            return SmsStore.getSenders(MainActivity.this);
        }

        @JavascriptInterface
        public void setSenders(String senders) {
            SmsStore.setSenders(MainActivity.this, senders);
        }

        /** Writes a text file into the public Downloads folder (no storage permission needed). */
        @JavascriptInterface
        public boolean saveFile(String name, String content) {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return false;
                OutputStream os = getContentResolver().openOutputStream(uri);
                if (os == null) return false;
                try {
                    os.write(content.getBytes(StandardCharsets.UTF_8));
                } finally {
                    os.close();
                }
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
}
