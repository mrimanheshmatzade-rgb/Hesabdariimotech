package com.hesabdari.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Called by Android for every incoming SMS. Only messages that look like bank transactions are
 * kept (everything else is ignored and never stored). The web app does the actual parsing.
 */
public class SmsReceiver extends BroadcastReceiver {
    static final String CHANNEL_ID = "bank_sms";

    // One-time passwords / dynamic codes must never end up in the ledger.
    private static final Pattern OTP = Pattern.compile(
            "رمز\\s*(پویا|دوم|یکبار|یک\\s*بار|ورود)|کد\\s*(تایید|تأیید|فعال\\s*سازی|یکبار|ورود)|پویا|\\botp\\b|cvv2",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern WORDS = Pattern.compile(
            "برداشت|واریز|پرید|مانده|موجودی|ریال|تومان|اضافه\\s*شد|کسر|نشست");
    private static final Pattern DIGITS = Pattern.compile("[0-9\\u06F0-\\u06F9\\u0660-\\u0669]{3,}");

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            if (intent == null || !Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
            SmsMessage[] parts = Telephony.Sms.Intents.getMessagesFromIntent(intent);
            if (parts == null || parts.length == 0) return;

            long ts = parts[0] != null ? parts[0].getTimestampMillis() : 0L;
            if (ts <= 0L) ts = System.currentTimeMillis();

            // A long SMS arrives in several parts: join the parts that share a sender.
            Map<String, StringBuilder> bodies = new LinkedHashMap<>();
            for (SmsMessage m : parts) {
                if (m == null) continue;
                String addr = m.getOriginatingAddress();
                if (addr == null) addr = "";
                String body = m.getMessageBody();
                if (body == null) body = "";
                StringBuilder sb = bodies.get(addr);
                if (sb == null) {
                    sb = new StringBuilder();
                    bodies.put(addr, sb);
                }
                sb.append(body);
            }

            boolean any = false;
            for (Map.Entry<String, StringBuilder> e : bodies.entrySet()) {
                String sender = e.getKey();
                String body = e.getValue().toString();
                if (accept(context, sender, body) && SmsStore.add(context, sender, body, ts)) any = true;
            }
            if (any) {
                notifyUser(context);
                MainActivity.pokeWeb();
            }
        } catch (Exception ignored) {
            // A receiver must never crash; at worst one message is skipped.
        }
    }

    static boolean accept(Context context, String sender, String body) {
        if (body == null || body.length() == 0) return false;
        if (OTP.matcher(body).find()) return false;

        String list = SmsStore.getSenders(context).trim();
        if (list.length() > 0) {
            String from = sender == null ? "" : sender.toLowerCase(Locale.ROOT);
            boolean match = false;
            for (String s : list.split("[,،\\n]")) {
                String key = s.trim().toLowerCase(Locale.ROOT);
                if (key.length() > 0 && from.contains(key)) {
                    match = true;
                    break;
                }
            }
            if (!match) return false;
        }
        return WORDS.matcher(body).find() && DIGITS.matcher(body).find();
    }

    private void notifyUser(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "پیامک‌های بانکی", NotificationManager.IMPORTANCE_DEFAULT);
        nm.createNotificationChannel(ch);

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                context, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // The text is deliberately generic: no amounts on the lock screen.
        Notification n = new Notification.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("دفتر")
                .setContentText("یک تراکنش بانکی جدید منتظر انتخاب دسته است")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        nm.notify(1, n);
    }
}
